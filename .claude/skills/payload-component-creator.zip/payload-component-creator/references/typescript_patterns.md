# TypeScript Patterns for Payload CMS

## Core Principles

1. **Strict typing** - No `any` types allowed
2. **Type imports** - Always use `import type` for type-only imports
3. **Payload types** - Use auto-generated types from `payload-types.ts`
4. **Interface over type** - Prefer interfaces for object shapes

## Common Patterns

### Block Component Props

```typescript
import type { Media } from '@/payload-types'

export interface BlockProps {
  // Required fields
  id: string
  blockType: string

  // Optional fields with proper types
  heading?: string
  content?: string

  // Media fields
  image?: Media | string // Can be object or ID

  // Array fields
  items?: {
    id: string
    title: string
    description?: string
  }[]

  // Enum fields
  variant?: 'primary' | 'secondary' | 'tertiary'

  // Rich text fields
  richText?: any // Lexical editor output
}
```

### Type Guards

```typescript
// Check if media is object or string ID
export function isMediaObject(media: Media | string | null): media is Media {
  return media !== null && typeof media === 'object'
}

// Usage
if (isMediaObject(props.image)) {
  return <OptimizedImage src={props.image} />
}
```

### Generic Collection Types

```typescript
import type { Page, Post, Category } from '@/payload-types'

// Generic fetch function
async function fetchCollection<T>(
  collection: string,
  where?: Where,
): Promise<T[]> {
  const payload = await getPayload()
  const { docs } = await payload.find({
    collection,
    where,
    depth: 2,
  })
  return docs as T[]
}

// Usage
const posts = await fetchCollection<Post>('posts', {
  _status: { equals: 'published' }
})
```

### Component Prop Extensions

```typescript
// Extend HTML element props
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary'
  size?: 'sm' | 'md' | 'lg'
  iconLeading?: React.ComponentType<{ className?: string }>
  iconTrailing?: React.ComponentType<{ className?: string }>
}

// Extend with Payload block props
interface HeroBlockProps extends BlockProps {
  heading: string
  subheading?: string
  cta?: {
    label: string
    url: string
    variant?: ButtonProps['variant']
  }
}
```

### Server Component Data Fetching

```typescript
// Server component with proper typing
export async function BlogList({
  category
}: {
  category?: string
}) {
  const payload = await getPayload()

  const where: Where = {
    _status: { equals: 'published' },
    ...(category && {
      'categories.slug': { equals: category }
    })
  }

  const { docs: posts } = await payload.find({
    collection: 'posts',
    where,
    sort: '-publishedAt',
    depth: 2,
  })

  return <PostGrid posts={posts} />
}
```

### Admin Field Components

```typescript
'use client'

import type { TextFieldClientProps } from '@payloadcms/ui'
import { useField } from '@payloadcms/ui'

export function CustomTextField({
  path,
  validate
}: TextFieldClientProps) {
  const { value, setValue, showError, errorMessage } = useField<string>({
    path,
    validate,
  })

  return (
    <div>
      <input
        value={value || ''}
        onChange={(e) => setValue(e.target.value)}
      />
      {showError && <span>{errorMessage}</span>}
    </div>
  )
}
```

### Discriminated Unions

```typescript
// Block types with discriminated unions
type ContentBlock =
  | {
      blockType: 'hero'
      heading: string
      subheading?: string
      backgroundImage?: Media | string
    }
  | {
      blockType: 'features'
      features: Feature[]
      columns?: 2 | 3 | 4
    }
  | {
      blockType: 'cta'
      title: string
      description: string
      button: {
        label: string
        url: string
      }
    }

// Type narrowing in components
function renderBlock(block: ContentBlock) {
  switch (block.blockType) {
    case 'hero':
      return <HeroBlock {...block} />
    case 'features':
      return <FeaturesBlock {...block} />
    case 'cta':
      return <CTABlock {...block} />
  }
}
```

### Async Component Patterns

```typescript
// Async server component
async function PageContent({ slug }: { slug: string }) {
  const page = await fetchPage(slug)

  if (!page) {
    notFound()
  }

  return <Layout blocks={page.layout} />
}

// With error boundary
export default async function Page({
  params
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params

  return (
    <ErrorBoundary fallback={<ErrorFallback />}>
      <Suspense fallback={<LoadingSkeleton />}>
        <PageContent slug={slug} />
      </Suspense>
    </ErrorBoundary>
  )
}
```

## Type Generation

Always regenerate types after schema changes:

```bash
pnpm generate:types
```

This updates `/src/payload-types.ts` with the latest collection types.