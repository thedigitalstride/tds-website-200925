# Styling Patterns for Payload Components

## Three-Layer Architecture

1. **CSS Variables** (theme.css) - Define all design tokens
2. **Tailwind Classes** - Apply variables via utility classes
3. **Dark Mode** - Automatic through CSS variable switching

## CSS Variable System

### Available Variables

```css
/* Colors */
--color-bg-primary        /* Main background */
--color-bg-secondary      /* Secondary background */
--color-bg-tertiary       /* Tertiary background */
--color-text-primary      /* Main text */
--color-text-secondary    /* Secondary text */
--color-text-tertiary     /* Tertiary text */
--color-border-primary    /* Main border */
--color-border-secondary  /* Secondary border */
--color-brand-primary     /* #031A43 */
--color-brand-secondary   /* #1689FF */

/* Spacing */
--spacing-xs   /* 4px */
--spacing-sm   /* 8px */
--spacing-md   /* 16px */
--spacing-lg   /* 24px */
--spacing-xl   /* 32px */
--spacing-2xl  /* 48px */
--spacing-3xl  /* 64px */

/* Typography */
--font-size-xs    /* 12px */
--font-size-sm    /* 14px */
--font-size-base  /* 16px */
--font-size-lg    /* 18px */
--font-size-xl    /* 20px */
--font-size-2xl   /* 24px */
--font-size-3xl   /* 30px */
--font-size-4xl   /* 36px */

/* Layout */
--radius-sm    /* 4px */
--radius-md    /* 8px */
--radius-lg    /* 12px */
--radius-full  /* 9999px */
```

## Component Styling Patterns

### Basic Component Structure

```tsx
export function Card({ children, className }: CardProps) {
  return (
    <div className={cn(
      // Base styles using CSS variables
      "bg-color-bg-secondary",
      "text-color-text-primary",
      "border border-color-border-primary",
      "rounded-radius-md",
      "p-spacing-lg",

      // Interactive states
      "transition-colors duration-200",
      "hover:bg-color-bg-tertiary",

      // Allow customization
      className
    )}>
      {children}
    </div>
  )
}
```

### Responsive Design

```tsx
// Mobile-first responsive utilities
<div className="
  grid cols-1 gap-spacing-md
  md:cols-2 md:gap-spacing-lg
  lg:cols-3 lg:gap-spacing-xl
">

// Container widths
<div className="
  w-full max-w-7xl mx-auto
  px-spacing-md md:px-spacing-lg lg:px-spacing-xl
">
```

### Dark Mode Support

```css
/* CSS automatically switches via variables */
.component {
  /* These variables change in dark mode */
  background: var(--color-bg-primary);
  color: var(--color-text-primary);
  border-color: var(--color-border-primary);
}

/* No need for dark: prefixes in most cases */
```

### UUI Component Integration

```tsx
import { Button } from '@/components/uui/button'
import { Badge } from '@/components/uui/badge'
import { Avatar } from '@/components/uui/avatar'

// UUI components already use CSS variables
<Button
  variant="primary"
  size="md"
  iconLeading={ChevronRight}
>
  Click me
</Button>

// Combining with custom styles
<div className="flex items-center gap-spacing-md">
  <Avatar src={user.image} alt={user.name} />
  <Badge variant="success">Active</Badge>
</div>
```

## Common Patterns

### Card with Hover Effect

```tsx
<div className="
  bg-color-bg-secondary
  border border-color-border-primary
  rounded-radius-lg
  p-spacing-xl
  transition-all duration-200
  hover:shadow-lg
  hover:-translate-y-1
  hover:border-color-brand-secondary
">
```

### Section Container

```tsx
<section className="
  py-spacing-3xl
  bg-color-bg-primary
  border-b border-color-border-primary
">
  <div className="
    max-w-7xl mx-auto
    px-spacing-md md:px-spacing-lg
  ">
    {/* Content */}
  </div>
</section>
```

### Typography Hierarchy

```tsx
<h1 className="text-font-size-4xl font-semibold text-color-text-primary">
  Main Heading
</h1>

<h2 className="text-font-size-2xl font-medium text-color-text-primary mt-spacing-xl">
  Section Heading
</h2>

<p className="text-font-size-base text-color-text-secondary mt-spacing-md">
  Body text content
</p>

<span className="text-font-size-sm text-color-text-tertiary">
  Caption text
</span>
```

### Grid Layouts

```tsx
// Feature grid
<div className="
  grid cols-1 md:cols-2 lg:cols-3
  gap-spacing-lg
">

// Blog post grid
<div className="
  grid cols-1 md:cols-2 lg:cols-3
  gap-x-spacing-lg gap-y-spacing-2xl
">

// Testimonial grid
<div className="
  grid cols-1 lg:cols-2
  gap-spacing-xl
">
```

### Form Elements

```tsx
// Input field
<input className="
  w-full
  px-spacing-md py-spacing-sm
  bg-color-bg-secondary
  border border-color-border-primary
  rounded-radius-md
  text-color-text-primary
  placeholder:text-color-text-tertiary
  focus:outline-none
  focus:ring-2 focus:ring-color-brand-secondary
  focus:border-color-brand-secondary
" />

// Textarea
<textarea className="
  w-full min-h-[120px]
  px-spacing-md py-spacing-sm
  bg-color-bg-secondary
  border border-color-border-primary
  rounded-radius-md
  text-color-text-primary
  resize-vertical
" />
```

## Animation Patterns

### Fade In

```tsx
<div className="
  animate-fadeIn
  opacity-0
  [animation-fill-mode:forwards]
">

/* In CSS */
@keyframes fadeIn {
  to {
    opacity: 1;
  }
}
```

### Slide In

```tsx
<div className="
  animate-slideInUp
  translate-y-4 opacity-0
  [animation-fill-mode:forwards]
">

/* In CSS */
@keyframes slideInUp {
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
```

## Performance Considerations

### Optimize Specificity

```tsx
// ✅ Good - Use utility classes
<div className="bg-color-bg-primary p-spacing-md">

// ❌ Avoid - Custom CSS with high specificity
<div style={{ backgroundColor: 'var(--color-bg-primary)', padding: '16px' }}>
```

### Reduce Reflows

```tsx
// ✅ Good - Fixed dimensions prevent layout shift
<div className="w-full aspect-video bg-color-bg-secondary">
  <OptimizedImage ... />
</div>

// ❌ Avoid - Dynamic content causing reflows
<div>
  <img src={...} />
</div>
```

## Debugging Tips

### Clear Cache After Theme Changes

```bash
rm -rf .next && pnpm dev
```

### Verify CSS Variable Exists

```tsx
// Check in browser DevTools
getComputedStyle(document.documentElement)
  .getPropertyValue('--color-bg-primary')
```

### Test Dark Mode

```javascript
// Toggle in browser console
document.documentElement.classList.toggle('dark')
```