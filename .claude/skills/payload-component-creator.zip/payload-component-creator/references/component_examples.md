# Component Examples from TDS Website

Real-world examples from the TDS website codebase to reference when creating new components.

## Block Component Example: Hero Block

### Component File (`src/blocks/Hero/Component.tsx`)

```typescript
import React from 'react'
import type { Media } from '@/payload-types'
import { OptimizedImage } from '@/components/OptimizedImage'
import { Button } from '@/components/uui/button'
import { ChevronRight } from 'lucide-react'
import { cn } from '@/utilities/cn'

export interface HeroBlockProps {
  heading: string
  subheading?: string
  description?: string
  backgroundImage?: Media | string
  cta?: {
    label: string
    url: string
    variant?: 'primary' | 'secondary'
  }
  alignment?: 'left' | 'center' | 'right'
}

export function HeroBlock({
  heading,
  subheading,
  description,
  backgroundImage,
  cta,
  alignment = 'center'
}: HeroBlockProps) {
  const isMediaObject = (media: any): media is Media => {
    return media && typeof media === 'object' && 'url' in media
  }

  return (
    <section className="relative min-h-[600px] flex items-center">
      {/* Background Image */}
      {backgroundImage && isMediaObject(backgroundImage) && (
        <div className="absolute inset-0 z-0">
          <OptimizedImage
            src={backgroundImage}
            alt={backgroundImage.alt || ''}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-black/60" />
        </div>
      )}

      {/* Content */}
      <div className={cn(
        "relative z-10 w-full max-w-7xl mx-auto px-spacing-md md:px-spacing-lg",
        alignment === 'center' && "text-center",
        alignment === 'left' && "text-left",
        alignment === 'right' && "text-right"
      )}>
        {subheading && (
          <p className="text-color-brand-secondary text-font-size-sm font-medium uppercase tracking-wide mb-spacing-sm">
            {subheading}
          </p>
        )}

        <h1 className="text-font-size-4xl md:text-5xl font-bold text-white mb-spacing-lg">
          {heading}
        </h1>

        {description && (
          <p className="text-font-size-lg text-white/90 mb-spacing-xl max-w-2xl mx-auto">
            {description}
          </p>
        )}

        {cta && (
          <Button
            variant={cta.variant || 'primary'}
            size="lg"
            href={cta.url}
            iconTrailing={ChevronRight}
          >
            {cta.label}
          </Button>
        )}
      </div>
    </section>
  )
}
```

### Config File (`src/blocks/Hero/config.ts`)

```typescript
import type { Block } from 'payload'

export const HeroBlock: Block = {
  slug: 'hero',
  labels: {
    singular: 'Hero Block',
    plural: 'Hero Blocks',
  },
  fields: [
    {
      name: 'heading',
      type: 'text',
      required: true,
      admin: {
        description: 'Main heading text',
      },
    },
    {
      name: 'subheading',
      type: 'text',
      admin: {
        description: 'Optional subheading above the main heading',
      },
    },
    {
      name: 'description',
      type: 'textarea',
      admin: {
        description: 'Optional description text',
        rows: 3,
      },
    },
    {
      name: 'backgroundImage',
      type: 'upload',
      relationTo: 'media',
      admin: {
        description: 'Background image for the hero section',
      },
    },
    {
      type: 'group',
      name: 'cta',
      label: 'Call to Action',
      admin: {
        condition: (data, siblingData) => siblingData?.heading,
      },
      fields: [
        {
          name: 'label',
          type: 'text',
          required: true,
        },
        {
          name: 'url',
          type: 'text',
          required: true,
        },
        {
          name: 'variant',
          type: 'select',
          options: [
            { label: 'Primary', value: 'primary' },
            { label: 'Secondary', value: 'secondary' },
          ],
          defaultValue: 'primary',
        },
      ],
    },
    {
      name: 'alignment',
      type: 'select',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
      ],
      defaultValue: 'center',
    },
  ],
}
```

## Field Component Example: Color Picker

### Field Component (`src/fields/colorPicker/Field.tsx`)

```typescript
'use client'

import React, { useState } from 'react'
import { useField } from '@payloadcms/ui'
import { HexColorPicker } from 'react-colorful'

interface ColorPickerFieldProps {
  path: string
  required?: boolean
}

export function ColorPickerField({ path, required }: ColorPickerFieldProps) {
  const { value, setValue, showError, errorMessage } = useField<string>({
    path,
  })

  const [isOpen, setIsOpen] = useState(false)

  const presetColors = [
    '#031A43', // Brand primary
    '#1689FF', // Brand secondary
    '#10B981', // Success
    '#F59E0B', // Warning
    '#EF4444', // Error
    '#6B7280', // Gray
  ]

  return (
    <div className="color-picker-field">
      <div className="flex items-center gap-spacing-md mb-spacing-sm">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="w-12 h-12 rounded-radius-md border-2 border-color-border-primary"
          style={{ backgroundColor: value || '#ffffff' }}
          aria-label="Choose color"
        />

        <input
          type="text"
          value={value || ''}
          onChange={(e) => setValue(e.target.value)}
          placeholder="#000000"
          className="flex-1 px-spacing-md py-spacing-sm border border-color-border-primary rounded-radius-md"
        />
      </div>

      {isOpen && (
        <div className="p-spacing-lg bg-color-bg-secondary rounded-radius-lg border border-color-border-primary">
          <HexColorPicker
            color={value || '#ffffff'}
            onChange={setValue}
          />

          <div className="flex gap-spacing-sm mt-spacing-md">
            {presetColors.map((color) => (
              <button
                key={color}
                type="button"
                onClick={() => setValue(color)}
                className="w-8 h-8 rounded-radius-sm border border-color-border-primary"
                style={{ backgroundColor: color }}
                aria-label={`Select ${color}`}
              />
            ))}
          </div>
        </div>
      )}

      {showError && (
        <p className="text-red-500 text-font-size-sm mt-spacing-xs">
          {errorMessage}
        </p>
      )}
    </div>
  )
}
```

### Field Config (`src/fields/colorPicker/config.ts`)

```typescript
import type { Field } from 'payload'

export const colorPickerField = (
  overrides?: Partial<Field>
): Field => ({
  type: 'text',
  admin: {
    components: {
      Field: '@/fields/colorPicker/Field',
    },
  },
  validate: (value: string) => {
    if (!value) return true

    // Validate hex color format
    const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/
    if (!hexRegex.test(value)) {
      return 'Please enter a valid hex color (e.g., #031A43)'
    }

    return true
  },
  ...overrides,
})

// Usage in collection
export const StyleSettings: Collection = {
  slug: 'styleSettings',
  fields: [
    {
      ...colorPickerField({
        name: 'primaryColor',
        label: 'Primary Color',
        required: true,
        defaultValue: '#031A43',
      }),
    },
  ],
}
```

## UI Component Example: Feature Card

### Component (`src/components/FeatureCard/index.tsx`)

```typescript
import React from 'react'
import { cn } from '@/utilities/cn'
import type { LucideIcon } from 'lucide-react'

export interface FeatureCardProps {
  title: string
  description: string
  icon?: LucideIcon
  variant?: 'default' | 'highlighted'
  className?: string
}

export function FeatureCard({
  title,
  description,
  icon: Icon,
  variant = 'default',
  className,
}: FeatureCardProps) {
  return (
    <div
      className={cn(
        // Base styles
        'group relative p-spacing-xl rounded-radius-lg',
        'transition-all duration-200',

        // Variant styles
        variant === 'default' && [
          'bg-color-bg-secondary',
          'border border-color-border-primary',
          'hover:border-color-brand-secondary',
          'hover:shadow-lg',
        ],
        variant === 'highlighted' && [
          'bg-gradient-to-br from-color-brand-primary to-color-brand-secondary',
          'text-white',
        ],

        className
      )}
    >
      {Icon && (
        <div
          className={cn(
            'w-12 h-12 rounded-radius-md',
            'flex items-center justify-center mb-spacing-md',
            variant === 'default' && 'bg-color-brand-primary/10',
            variant === 'highlighted' && 'bg-white/20'
          )}
        >
          <Icon
            className={cn(
              'w-6 h-6',
              variant === 'default' && 'text-color-brand-primary',
              variant === 'highlighted' && 'text-white'
            )}
          />
        </div>
      )}

      <h3
        className={cn(
          'text-font-size-xl font-semibold mb-spacing-sm',
          variant === 'default' && 'text-color-text-primary',
          variant === 'highlighted' && 'text-white'
        )}
      >
        {title}
      </h3>

      <p
        className={cn(
          'text-font-size-base',
          variant === 'default' && 'text-color-text-secondary',
          variant === 'highlighted' && 'text-white/90'
        )}
      >
        {description}
      </p>

      {/* Hover effect */}
      <div
        className={cn(
          'absolute inset-0 rounded-radius-lg opacity-0',
          'transition-opacity duration-200',
          'group-hover:opacity-100',
          variant === 'default' && 'bg-gradient-to-br from-color-brand-primary/5 to-color-brand-secondary/5'
        )}
      />
    </div>
  )
}

// Usage example
export function FeaturesSection() {
  const features = [
    {
      title: 'Fast Performance',
      description: 'Optimized for speed with Next.js and React Server Components',
      icon: Zap,
    },
    {
      title: 'Type Safe',
      description: 'Full TypeScript support with auto-generated Payload types',
      icon: Shield,
      variant: 'highlighted' as const,
    },
  ]

  return (
    <div className="grid cols-1 md:cols-2 lg:cols-3 gap-spacing-lg">
      {features.map((feature, index) => (
        <FeatureCard key={index} {...feature} />
      ))}
    </div>
  )
}
```

## Server Component with Data Fetching

```typescript
// src/components/BlogList/index.tsx
import { getPayload } from '@/utilities/getPayload'
import type { Post } from '@/payload-types'
import { PostCard } from '@/components/PostCard'

interface BlogListProps {
  limit?: number
  category?: string
}

export async function BlogList({
  limit = 6,
  category
}: BlogListProps) {
  const payload = await getPayload()

  const { docs: posts } = await payload.find({
    collection: 'posts',
    where: {
      _status: { equals: 'published' },
      ...(category && {
        'categories.slug': { equals: category }
      }),
    },
    sort: '-publishedAt',
    limit,
    depth: 2,
  })

  if (posts.length === 0) {
    return (
      <div className="text-center py-spacing-2xl">
        <p className="text-color-text-secondary">
          No posts found in this category.
        </p>
      </div>
    )
  }

  return (
    <div className="grid cols-1 md:cols-2 lg:cols-3 gap-spacing-xl">
      {posts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
    </div>
  )
}
```