---
name: payload-component-creator
description: Structured process for creating new Payload CMS React components following TDS website patterns. This skill should be used when creating Block components for layout builders, Field components for admin panels, or UI components for frontend display in Payload CMS projects, ensuring consistent TypeScript patterns, proper file organization, and adherence to CSS variable-based styling systems.
---

# Payload Component Creator

## Overview

This skill provides a systematic workflow for creating Payload CMS React components using a "Component First" approach, emphasizing TypeScript patterns, proper file organization, and CSS variable-based styling systems.

## Workflow Decision Tree

When creating a new Payload component, determine the component type first:

```
User requests new component
├── Is it for content blocks in layout builder? → Block Component
├── Is it for custom admin input fields? → Field Component
└── Is it for frontend display/UI? → UI Component
```

## Phase 1: Component Planning

Before writing any code, establish clear requirements:

### Define Component Type and Location

**Block Components** (e.g., Hero, CTA, Features)
- Location: `src/blocks/[ComponentName]/`
- Files: `Component.tsx`, `config.ts`, `types.ts`

**Field Components** (e.g., ColorPicker, IconSelector)
- Location: `src/fields/[componentName]/`
- Files: `Field.tsx`, `config.ts`, `types.ts`

**UI Components** (e.g., Card, Badge, Layout)
- Location: `src/components/[ComponentName]/`
- Files: `index.tsx`, `types.ts`

### Identify Requirements

Create a requirements checklist:
- List all data fields/props needed
- Determine required vs optional fields
- Plan responsive breakpoints
- Consider dark mode variations
- Note any animations or interactions

### Review Existing Patterns

Check the codebase for similar components:
```bash
# Find similar block components
grep -r "Block" src/blocks/ --include="*.tsx"

# Check existing field implementations
grep -r "Field" src/fields/ --include="*.ts"

# Review UI component patterns
ls -la src/components/
```

## Phase 2: Component First Development

Build the React component before Payload integration:

### Step 1: Create TypeScript Interface

Start with the interface definition:

```typescript
// For Block Components
import type { Media } from '@/payload-types'

export interface TestimonialBlockProps {
  testimonials: {
    id: string
    quote: string
    author: string
    role?: string
    company?: string
    image?: Media | string
  }[]
  heading?: string
  subheading?: string
}

// For UI Components
export interface FeatureCardProps {
  title: string
  description: string
  icon?: React.ComponentType<{ className?: string }>
  variant?: 'default' | 'highlighted'
  className?: string
}
```

### Step 2: Build Component with Mock Data

Create the component with temporary data:

```typescript
// Start with mock implementation
const mockData: TestimonialBlockProps = {
  testimonials: [
    {
      id: '1',
      quote: 'This is amazing',
      author: 'John Doe',
      role: 'CEO',
      company: 'Tech Corp'
    }
  ],
  heading: 'What Our Customers Say'
}

export function TestimonialBlock(props: TestimonialBlockProps) {
  const data = props || mockData // Use mock data during development
  // Component implementation
}
```

### Step 3: Apply Styling System

Follow the three-layer styling architecture:

```typescript
// ✅ CORRECT: Use CSS variables from theme
<div className="bg-color-bg-primary text-color-text-primary p-spacing-md">

// ❌ WRONG: Don't use arbitrary values
<div className="bg-[#031A43] text-[14px] p-[20px]">
```

Check `theme.css` for available variables:
- Colors: `var(--color-*)`
- Spacing: `var(--spacing-*)`
- Typography: `var(--font-*)`

### Step 4: Add Dark Mode Support

Implement dark mode using CSS variables:

```css
/* Component automatically adapts via CSS variables */
.component {
  background: var(--color-bg-primary);
  color: var(--color-text-primary);
}
```

### Step 5: Implement Responsive Design

Use Tailwind's responsive prefixes:

```typescript
<div className="grid cols-1 md:cols-2 lg:cols-3 gap-spacing-md">
```

## Phase 3: Payload Integration

Connect the component to Payload CMS:

### For Block Components

1. Create block configuration:

```typescript
// src/blocks/TestimonialBlock/config.ts
import type { Block } from 'payload'

export const TestimonialBlock: Block = {
  slug: 'testimonialBlock',
  labels: {
    singular: 'Testimonial Block',
    plural: 'Testimonial Blocks',
  },
  fields: [
    {
      name: 'heading',
      type: 'text',
      required: false,
    },
    {
      name: 'testimonials',
      type: 'array',
      required: true,
      minRows: 1,
      fields: [
        {
          name: 'quote',
          type: 'textarea',
          required: true,
        },
        {
          name: 'author',
          type: 'text',
          required: true,
        },
        // Additional fields...
      ],
    },
  ],
}
```

2. Add to collection:

```typescript
// src/collections/Pages/index.ts
import { TestimonialBlock } from '@/blocks/TestimonialBlock/config'

export const Pages: Collection = {
  // ...
  fields: [
    {
      name: 'layout',
      type: 'blocks',
      blocks: [
        // Existing blocks...
        TestimonialBlock, // Add new block
      ],
    },
  ],
}
```

### For Field Components

1. Create field configuration:

```typescript
// src/fields/iconSelector/config.ts
import type { Field } from 'payload'

export const iconSelectorField: Field = {
  name: 'icon',
  type: 'text',
  admin: {
    components: {
      Field: '@/fields/iconSelector/Field',
    },
  },
  validate: (value) => {
    if (!value) return true
    // Custom validation logic
    return true
  },
}
```

2. Implement admin component:

```typescript
// src/fields/iconSelector/Field.tsx
'use client'

import { useField } from '@payloadcms/ui'

export function IconSelectorField({ path }: { path: string }) {
  const { value, setValue } = useField<string>({ path })

  return (
    // Custom field UI
  )
}
```

## Phase 4: Testing and Optimization

### Type Safety Verification

```bash
# Regenerate types after schema changes
pnpm generate:types

# Check for TypeScript errors
pnpm tsc --noEmit
```

### Performance Optimization

Always use OptimizedImage for images:

```typescript
import { OptimizedImage } from '@/components/OptimizedImage'

// ✅ CORRECT
<OptimizedImage
  src={media}
  alt={alt}
  sizes="(max-width: 768px) 100vw, 50vw"
  priority={isAboveFold}
/>

// ❌ WRONG: Never use <img> directly
<img src={url} alt={alt} />
```

### Visual Testing Checklist

- [ ] Test in light mode
- [ ] Test in dark mode
- [ ] Check all responsive breakpoints
- [ ] Verify loading states
- [ ] Test error states
- [ ] Check empty states

### Accessibility Verification

- [ ] Proper heading hierarchy
- [ ] ARIA labels on interactive elements
- [ ] Keyboard navigation works
- [ ] Color contrast meets WCAG standards
- [ ] Focus indicators visible

## Phase 5: Documentation and Cleanup

### Add Component Documentation

Create a README in the component directory:

```markdown
# TestimonialBlock

Displays customer testimonials in a responsive grid layout.

## Usage

\```tsx
import { TestimonialBlock } from '@/blocks/TestimonialBlock'

<TestimonialBlock
  heading="Customer Success Stories"
  testimonials={testimonials}
/>
\```

## Props

- `heading` (optional): Section heading
- `testimonials` (required): Array of testimonial objects
  - `quote`: Customer testimonial text
  - `author`: Name of the person
  - `role`: Job title (optional)
  - `company`: Company name (optional)
  - `image`: Profile image (optional)
```

### Final Cleanup

```bash
# Format code
pnpm prettier --write src/blocks/TestimonialBlock

# Fix linting issues
pnpm lint:fix

# Run final type check
pnpm generate:types
```

## Common Pitfalls and Solutions

### Database Schema Issues

**Problem**: "Column does not exist" error after adding fields

**Solution**:
```bash
# In development: Let auto-sync handle it
pnpm dev
# Wait for "✓ Schema synchronized" message

# Never run migrations in development!
```

### Styling Not Applied

**Problem**: CSS classes not working

**Solution**:
1. Clear Next.js cache: `rm -rf .next`
2. Verify CSS variable exists in `theme.css`
3. Check class name matches Tailwind v4 syntax
4. Restart dev server

### TypeScript Type Errors

**Problem**: Types don't match after changes

**Solution**:
```bash
# Always regenerate after schema changes
pnpm generate:types

# Import from correct location
import type { Media } from '@/payload-types'
```

## Resources

This skill includes helpful templates and references:

### scripts/
- `generate_block_component.py` - Scaffolds new block components
- `generate_field_component.py` - Creates custom field components
- `generate_ui_component.py` - Generates UI components

### references/
- `typescript_patterns.md` - TypeScript best practices for Payload
- `styling_patterns.md` - CSS variables and Tailwind patterns
- `component_examples.md` - Real-world component implementations

### assets/templates/
- `block/` - Block component boilerplate
- `field/` - Field component templates
- `ui/` - UI component starter files