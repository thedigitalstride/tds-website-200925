#!/usr/bin/env python3
"""
Generate a new Payload Field component with admin UI and validation.

Usage:
    python3 generate_field_component.py --name "iconSelector" --type "text"
"""

import argparse
import os
import sys
from pathlib import Path


def camel_to_pascal(name):
    """Convert camelCase to PascalCase."""
    return name[0].upper() + name[1:] if name else ''


def generate_field_tsx(name, field_type):
    """Generate the Field UI component."""
    pascal_name = camel_to_pascal(name)

    return f''''use client'

import React, {{ useState }} from 'react'
import {{ useField }} from '@payloadcms/ui'
import {{ cn }} from '@/utilities/cn'

interface {pascal_name}FieldProps {{
  path: string
  required?: boolean
  label?: string
  description?: string
}}

export function {pascal_name}Field({{
  path,
  required,
  label,
  description,
}}: {pascal_name}FieldProps) {{
  const {{ value, setValue, showError, errorMessage }} = useField<string>({{
    path,
  }})

  const [isFocused, setIsFocused] = useState(false)

  return (
    <div className="field-wrapper">
      {{label && (
        <label className="block text-font-size-sm font-medium text-color-text-primary mb-spacing-xs">
          {{label}}
          {{required && <span className="text-red-500 ml-1">*</span>}}
        </label>
      )}}

      {{description && (
        <p className="text-font-size-sm text-color-text-secondary mb-spacing-sm">
          {{description}}
        </p>
      )}}

      <div className="relative">
        {{/* TODO: Implement custom field UI */}}
        <input
          type="text"
          value={{value || ''}}
          onChange={{(e) => setValue(e.target.value)}}
          onFocus={{() => setIsFocused(true)}}
          onBlur={{() => setIsFocused(false)}}
          className={{cn(
            'w-full px-spacing-md py-spacing-sm',
            'bg-color-bg-secondary',
            'border rounded-radius-md',
            'text-color-text-primary',
            'placeholder:text-color-text-tertiary',
            'transition-all duration-200',
            isFocused
              ? 'border-color-brand-secondary ring-2 ring-color-brand-secondary/20'
              : 'border-color-border-primary',
            showError && 'border-red-500',
          )}}
          placeholder="Enter value..."
        />

        {{/* Add custom UI elements here */}}
      </div>

      {{showError && (
        <p className="text-red-500 text-font-size-sm mt-spacing-xs">
          {{errorMessage}}
        </p>
      )}}
    </div>
  )
}}
'''


def generate_config_ts(name, field_type):
    """Generate the field configuration."""
    pascal_name = camel_to_pascal(name)

    return f'''import type {{ Field }} from 'payload'

export const {name}Field = (
  overrides?: Partial<Field>
): Field => ({{
  type: '{field_type}',
  admin: {{
    components: {{
      Field: '@/fields/{name}/Field',
    }},
  }},
  validate: (value, {{ required }}) => {{
    // Custom validation logic
    if (required && !value) {{
      return 'This field is required'
    }}

    // TODO: Add custom validation
    // Example: validate format, length, etc.

    return true
  }},
  hooks: {{
    beforeValidate: [
      async ({{ value }}) => {{
        // Process value before validation
        // Example: trim whitespace, normalize format
        if (typeof value === 'string') {{
          return value.trim()
        }}
        return value
      }},
    ],
  }},
  ...overrides,
}})

// Helper function for easy use in collections
export const create{pascal_name}Field = ({{
  name,
  label,
  required = false,
  defaultValue,
  ...overrides
}}: {{
  name: string
  label?: string
  required?: boolean
  defaultValue?: string
}} & Partial<Field>) => ({{
  ...{name}Field(overrides),
  name,
  label,
  required,
  defaultValue,
}})
'''


def generate_index_ts(name):
    """Generate the index file."""
    pascal_name = camel_to_pascal(name)

    return f'''export {{ {pascal_name}Field }} from './Field'
export {{ {name}Field, create{pascal_name}Field }} from './config'
'''


def generate_types_ts(name, field_type):
    """Generate TypeScript type definitions."""
    pascal_name = camel_to_pascal(name)

    return f'''// Type definitions for {name} field

export interface {pascal_name}Value {{
  // TODO: Define the structure of your field value
  value: string
  metadata?: {{
    [key: string]: any
  }}
}}

export interface {pascal_name}FieldConfig {{
  name: string
  label?: string
  required?: boolean
  defaultValue?: string | {pascal_name}Value
  validate?: (value: any, options: any) => boolean | string
}}
'''


def main():
    parser = argparse.ArgumentParser(description='Generate a new Payload Field component')
    parser.add_argument('--name', required=True, help='Field name (camelCase)')
    parser.add_argument('--type', default='text', choices=['text', 'textarea', 'number', 'select', 'checkbox', 'date', 'json'],
                      help='Base field type')
    parser.add_argument('--output', default='./src/fields', help='Output directory')

    args = parser.parse_args()

    # Create field directory
    field_dir = Path(args.output) / args.name
    field_dir.mkdir(parents=True, exist_ok=True)

    # Generate files
    files = {
        'Field.tsx': generate_field_tsx(args.name, args.type),
        'config.ts': generate_config_ts(args.name, args.type),
        'index.ts': generate_index_ts(args.name),
        'types.ts': generate_types_ts(args.name, args.type),
    }

    for filename, content in files.items():
        file_path = field_dir / filename
        file_path.write_text(content)
        print(f"✅ Created {file_path}")

    pascal_name = camel_to_pascal(args.name)
    print(f"\n🎉 Field component '{args.name}' generated successfully!")
    print(f"\nNext steps:")
    print(f"1. Import the field in your collection:")
    print(f"   import {{ create{pascal_name}Field }} from '@/fields/{args.name}'")
    print(f"2. Use in your collection fields:")
    print(f"   create{pascal_name}Field({{ name: 'myField', label: 'My Field' }})")
    print(f"3. Implement the custom UI in Field.tsx")
    print(f"4. Add validation logic in config.ts")
    print(f"5. Run 'pnpm generate:types' to update TypeScript types")


if __name__ == '__main__':
    main()