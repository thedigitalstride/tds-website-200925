#!/usr/bin/env python3
"""
Generate a new UI component with TypeScript props and styling.

Usage:
    python3 generate_ui_component.py --name "FeatureCard" --props "title:string,description:string,icon:ReactNode"
"""

import argparse
import os
import sys
from pathlib import Path


def generate_component_tsx(name, props):
    """Generate the React component file."""
    props_interface = []
    props_destructure = []
    default_props = []

    for prop in props:
        if ':' in prop:
            prop_name, prop_type = prop.split(':')
        else:
            prop_name = prop
            prop_type = 'string'

        # Map common types
        type_map = {
            'string': 'string',
            'number': 'number',
            'boolean': 'boolean',
            'ReactNode': 'React.ReactNode',
            'ReactElement': 'React.ReactElement',
            'function': '() => void',
            'icon': 'React.ComponentType<{ className?: string }>',
            'LucideIcon': 'LucideIcon',
        }

        ts_type = type_map.get(prop_type, prop_type)

        # Make all props optional by default except for common required ones
        if prop_name in ['children', 'title', 'name', 'id']:
            props_interface.append(f"  {prop_name}: {ts_type}")
        else:
            props_interface.append(f"  {prop_name}?: {ts_type}")

        props_destructure.append(prop_name)

        # Add default values for optional props
        if prop_name not in ['children', 'title', 'name', 'id']:
            if prop_type == 'boolean':
                default_props.append(f"  {prop_name} = false,")
            elif prop_type in ['string', 'number']:
                default_props.append(f"  {prop_name},")
            else:
                default_props.append(f"  {prop_name},")

    props_str = ',\n'.join(default_props) if default_props else '  // props'

    return f'''import React from 'react'
import {{ cn }} from '@/utilities/cn'
import type {{ LucideIcon }} from 'lucide-react'

export interface {name}Props {{
{chr(10).join(props_interface)}
  variant?: 'default' | 'primary' | 'secondary'
  size?: 'sm' | 'md' | 'lg'
  className?: string
}}

export function {name}({{
{props_str}
  variant = 'default',
  size = 'md',
  className,
}}: {name}Props) {{
  return (
    <div
      className={{cn(
        // Base styles
        'relative',
        'transition-all duration-200',

        // Size variants
        size === 'sm' && 'p-spacing-sm',
        size === 'md' && 'p-spacing-md',
        size === 'lg' && 'p-spacing-lg',

        // Variant styles
        variant === 'default' && [
          'bg-color-bg-secondary',
          'border border-color-border-primary',
          'text-color-text-primary',
          'hover:border-color-brand-secondary',
        ],
        variant === 'primary' && [
          'bg-color-brand-primary',
          'text-white',
          'hover:bg-color-brand-primary/90',
        ],
        variant === 'secondary' && [
          'bg-color-brand-secondary',
          'text-white',
          'hover:bg-color-brand-secondary/90',
        ],

        // Rounded corners
        'rounded-radius-lg',

        // Custom className
        className
      )}}
    >
      {{/* TODO: Implement {name} component UI */}}
      <div className="space-y-spacing-sm">
        <p className="text-font-size-sm text-color-text-secondary">
          {name} Component
        </p>
        <pre className="text-font-size-xs opacity-50">
          {{JSON.stringify({{ {', '.join(props_destructure)} }}, null, 2)}}
        </pre>
      </div>
    </div>
  )
}}

// Default export for lazy loading
export default {name}
'''


def generate_index_ts(name):
    """Generate the index file."""
    return f'''export {{ {name} }} from './{name}'
export type {{ {name}Props }} from './{name}'
'''


def generate_stories_tsx(name, props):
    """Generate Storybook stories file (optional)."""
    props_args = []
    for prop in props:
        if ':' in prop:
            prop_name, prop_type = prop.split(':')
            if prop_type == 'string':
                props_args.append(f"    {prop_name}: 'Sample {prop_name}',")
            elif prop_type == 'number':
                props_args.append(f"    {prop_name}: 42,")
            elif prop_type == 'boolean':
                props_args.append(f"    {prop_name}: true,")

    return f'''import type {{ Meta, StoryObj }} from '@storybook/react'
import {{ {name} }} from './{name}'

const meta = {{
  title: 'Components/{name}',
  component: {name},
  parameters: {{
    layout: 'centered',
  }},
  tags: ['autodocs'],
  argTypes: {{
    variant: {{
      control: {{ type: 'select' }},
      options: ['default', 'primary', 'secondary'],
    }},
    size: {{
      control: {{ type: 'select' }},
      options: ['sm', 'md', 'lg'],
    }},
  }},
}} satisfies Meta<typeof {name}>

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {{
  args: {{
{chr(10).join(props_args) if props_args else '    // Add default props here'}
  }},
}}

export const Primary: Story = {{
  args: {{
    ...Default.args,
    variant: 'primary',
  }},
}}

export const Secondary: Story = {{
  args: {{
    ...Default.args,
    variant: 'secondary',
  }},
}}

export const Small: Story = {{
  args: {{
    ...Default.args,
    size: 'sm',
  }},
}}

export const Large: Story = {{
  args: {{
    ...Default.args,
    size: 'lg',
  }},
}}
'''


def generate_test_tsx(name):
    """Generate test file."""
    return f'''import {{ render, screen }} from '@testing-library/react'
import {{ describe, it, expect }} from 'vitest'
import {{ {name} }} from './{name}'

describe('{name}', () => {{
  it('renders without crashing', () => {{
    render(<{name} />)
    expect(screen.getByText(/{name} Component/i)).toBeInTheDocument()
  }})

  it('applies custom className', () => {{
    const {{ container }} = render(<{name} className="custom-class" />)
    expect(container.firstChild).toHaveClass('custom-class')
  }})

  it('renders different variants', () => {{
    const {{ rerender, container }} = render(<{name} variant="primary" />)
    expect(container.firstChild).toHaveClass('bg-color-brand-primary')

    rerender(<{name} variant="secondary" />)
    expect(container.firstChild).toHaveClass('bg-color-brand-secondary')
  }})

  it('renders different sizes', () => {{
    const {{ rerender, container }} = render(<{name} size="sm" />)
    expect(container.firstChild).toHaveClass('p-spacing-sm')

    rerender(<{name} size="lg" />)
    expect(container.firstChild).toHaveClass('p-spacing-lg')
  }})
}})
'''


def main():
    parser = argparse.ArgumentParser(description='Generate a new UI component')
    parser.add_argument('--name', required=True, help='Component name (PascalCase)')
    parser.add_argument('--props', default='', help='Props in format "name:type,name:type"')
    parser.add_argument('--output', default='./src/components', help='Output directory')
    parser.add_argument('--with-tests', action='store_true', help='Generate test file')
    parser.add_argument('--with-stories', action='store_true', help='Generate Storybook stories')

    args = parser.parse_args()

    # Parse props
    props = [p.strip() for p in args.props.split(',')] if args.props else []

    # Create component directory
    component_dir = Path(args.output) / args.name
    component_dir.mkdir(parents=True, exist_ok=True)

    # Generate files
    files = {
        f'{args.name}.tsx': generate_component_tsx(args.name, props),
        'index.ts': generate_index_ts(args.name),
    }

    if args.with_stories:
        files[f'{args.name}.stories.tsx'] = generate_stories_tsx(args.name, props)

    if args.with_tests:
        files[f'{args.name}.test.tsx'] = generate_test_tsx(args.name)

    for filename, content in files.items():
        file_path = component_dir / filename
        file_path.write_text(content)
        print(f"✅ Created {file_path}")

    print(f"\n🎉 UI component '{args.name}' generated successfully!")
    print(f"\nNext steps:")
    print(f"1. Import the component where needed:")
    print(f"   import {{ {args.name} }} from '@/components/{args.name}'")
    print(f"2. Implement the component logic")
    print(f"3. Add proper TypeScript types for any complex props")
    print(f"4. Style using CSS variables from theme.css")
    print(f"5. Test in both light and dark modes")


if __name__ == '__main__':
    main()