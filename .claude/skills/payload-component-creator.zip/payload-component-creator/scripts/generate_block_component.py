#!/usr/bin/env python3
"""
Generate a new Payload Block component with TypeScript interfaces and configuration.

Usage:
    python3 generate_block_component.py --name "TestimonialGrid" --fields "testimonials:array,title:text,subtitle:text"
"""

import argparse
import os
import sys
from pathlib import Path


def pascal_to_kebab(name):
    """Convert PascalCase to kebab-case."""
    result = []
    for i, char in enumerate(name):
        if i > 0 and char.isupper():
            result.append('-')
        result.append(char.lower())
    return ''.join(result)


def generate_component_tsx(name, fields):
    """Generate the React component file."""
    fields_interface = []
    field_props = []

    for field in fields:
        field_name, field_type = field.split(':')

        if field_type == 'array':
            fields_interface.append(f"  {field_name}?: any[]")
        elif field_type == 'text':
            fields_interface.append(f"  {field_name}?: string")
        elif field_type == 'textarea':
            fields_interface.append(f"  {field_name}?: string")
        elif field_type == 'richtext':
            fields_interface.append(f"  {field_name}?: any // Lexical editor output")
        elif field_type == 'upload':
            fields_interface.append(f"  {field_name}?: Media | string")
        elif field_type == 'select':
            fields_interface.append(f"  {field_name}?: string")
        else:
            fields_interface.append(f"  {field_name}?: any")

        field_props.append(field_name)

    props_destructure = ',\n  '.join(field_props)

    return f'''import React from 'react'
import type {{ Media }} from '@/payload-types'
import {{ cn }} from '@/utilities/cn'

export interface {name}Props {{
  id?: string
  blockType?: string
{chr(10).join(fields_interface)}
}}

export function {name}({{
  {props_destructure}
}}: {name}Props) {{
  return (
    <section className="py-spacing-3xl">
      <div className="max-w-7xl mx-auto px-spacing-md md:px-spacing-lg">
        {{/* TODO: Implement {name} component */}}
        <div className="bg-color-bg-secondary p-spacing-xl rounded-radius-lg border border-color-border-primary">
          <pre className="text-color-text-secondary">
            {{JSON.stringify({{ {', '.join(field_props)} }}, null, 2)}}
          </pre>
        </div>
      </div>
    </section>
  )
}}
'''


def generate_config_ts(name, fields):
    """Generate the Payload configuration file."""
    fields_config = []

    for field in fields:
        field_name, field_type = field.split(':')

        if field_type == 'array':
            fields_config.append(f"""    {{
      name: '{field_name}',
      type: 'array',
      fields: [
        {{
          name: 'id',
          type: 'text',
        }},
        // TODO: Add array fields
      ],
    }}""")
        elif field_type == 'text':
            fields_config.append(f"""    {{
      name: '{field_name}',
      type: 'text',
    }}""")
        elif field_type == 'textarea':
            fields_config.append(f"""    {{
      name: '{field_name}',
      type: 'textarea',
      admin: {{
        rows: 4,
      }},
    }}""")
        elif field_type == 'richtext':
            fields_config.append(f"""    {{
      name: '{field_name}',
      type: 'richText',
    }}""")
        elif field_type == 'upload':
            fields_config.append(f"""    {{
      name: '{field_name}',
      type: 'upload',
      relationTo: 'media',
    }}""")
        elif field_type == 'select':
            fields_config.append(f"""    {{
      name: '{field_name}',
      type: 'select',
      options: [
        {{ label: 'Option 1', value: 'option1' }},
        {{ label: 'Option 2', value: 'option2' }},
      ],
    }}""")
        else:
            fields_config.append(f"""    {{
      name: '{field_name}',
      type: 'text',
    }}""")

    slug = pascal_to_kebab(name)

    return f'''import type {{ Block }} from 'payload'

export const {name}: Block = {{
  slug: '{slug}',
  labels: {{
    singular: '{name.replace(/([A-Z])/g, ' $1').strip()}',
    plural: '{name.replace(/([A-Z])/g, ' $1').strip()}s',
  }},
  fields: [
{','.join(fields_config)},
  ],
}}
'''


def generate_index_ts(name):
    """Generate the index file for the block."""
    return f'''export {{ {name} }} from './Component'
export {{ {name} as {name}Block }} from './config'
'''


def main():
    parser = argparse.ArgumentParser(description='Generate a new Payload Block component')
    parser.add_argument('--name', required=True, help='Component name (PascalCase)')
    parser.add_argument('--fields', required=True, help='Fields in format "name:type,name:type"')
    parser.add_argument('--output', default='./src/blocks', help='Output directory')

    args = parser.parse_args()

    # Parse fields
    fields = [f.strip() for f in args.fields.split(',')]

    # Create component directory
    component_dir = Path(args.output) / args.name
    component_dir.mkdir(parents=True, exist_ok=True)

    # Generate files
    files = {
        'Component.tsx': generate_component_tsx(args.name, fields),
        'config.ts': generate_config_ts(args.name, fields),
        'index.ts': generate_index_ts(args.name),
    }

    for filename, content in files.items():
        file_path = component_dir / filename
        file_path.write_text(content)
        print(f"✅ Created {file_path}")

    print(f"\n🎉 Block component '{args.name}' generated successfully!")
    print(f"\nNext steps:")
    print(f"1. Import the block in your collection:")
    print(f"   import {{ {args.name}Block }} from '@/blocks/{args.name}'")
    print(f"2. Add to the blocks array in your collection")
    print(f"3. Implement the component logic in Component.tsx")
    print(f"4. Run 'pnpm generate:types' to update TypeScript types")


if __name__ == '__main__':
    main()